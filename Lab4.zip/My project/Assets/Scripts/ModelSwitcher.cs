using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class ModelSwitcher : MonoBehaviour
{
    public GameObject[] models;
    public Button switcher;

    private int currentIndex = 0;
    // Start is called before the first frame update
    void Start()
    {
        switcher.onClick.AddListener(SwitchModels);
        ShowModels(0);
    }
    void SwitchModels()
    {
        currentIndex = (currentIndex + 1) % models.Length;
        ShowModels(currentIndex);
    }
    void ShowModels(int index)
    {
        for(int i = 0; i < models.Length; i++)
        {
            models[i].SetActive(i==index);
        }
    }


}
